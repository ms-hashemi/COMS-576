#############################################################################################################
# COM S 476/576 Project 4 Solution
# Mohammad Hashemi
#############################################################################################################

import json, sys, os, argparse
import numpy as np
import copy
import matplotlib.pyplot as plt
from discrete_search import fsearch, ALG_BFS
from draw_cspace import draw
import geometry
import graph


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="Run forward search")
    parser.add_argument(
        "desc",
        metavar="problem_description_path",
        type=str,
        help="path to the problem description file containing the obstacle region in the world as well as the size and shape of the robot, including the width and length of each link, and the distance between two points of attachment",
    )
    parser.add_argument(
        "--out",
        metavar="output_path",
        type=str,
        required=False,
        default="",
        dest="out",
        help="path to the output file",
    )

    args = parser.parse_args(sys.argv[1:])
    if not args.out:
        args.out = os.path.splitext(os.path.basename(args.desc))[0] + "_out" + ".json"

    print("Problem description: ", args.desc)
    print("Output:              ", args.out)

    return args


def parse_desc(desc):
    """Parse problem description json file to get the problem description"""
    with open(desc) as desc:
        data = json.load(desc)

    O = data["O"]
    dt = data["dt"]
    ORIGIN = data["ORIGIN"]
    W = data["W"]
    H = data["H"]
    QUERIES = data["QUERIES"]
    MAX_SAMPLES = data["MAX_SAMPLES"]
    RESOLUTION = data["RESOLUTION"]
    return (O, dt, ORIGIN, W, H, QUERIES, MAX_SAMPLES, RESOLUTION)


class search_space(object):
    def __init__(self, world, obstacles = None):
        self.world = world
        self.obstacles = obstacles

    def empty_collision_checker(self, q):
        return not self.world.contain(q)
    
    def obstacle_free(self, q):
        collision = False
        if self.obstacles:
            for obs in self.obstacles:
                if obs.contain(q):
                    collision = True
                    break
        return not collision

    def sample_free(self):
        while True:  # sample until not inside of an obstacle
            q = self.sample()
            if self.obstacle_free(q):
                return q

    def sample(self):
        bounds = self.world.get_bounds()
        return tuple(np.random.uniform(bounds[:, 0], bounds[:, 1]))


class edge_creator():
    def make_edge(self):
        raise NotImplementedError


class straight_edge_creator(edge_creator):
    def make_edge(self, G, node):
        G.vertices.append(node)
        G.edges.append((node.parent, node))


def stopping_config(s, q1_line, q2_line, delta_q):
    direction = []
    length = geometry.get_euclidean_distance(q1_line, q2_line)
    for i in range(len(q1_line)):
        direction.append((q2_line(i)-q1_line(i))/length)
    i = 0
    qs = copy.deepcopy(q1_line)
    qs_new = copy.deepcopy(q1_line)
    nearest_point = [0, 0]
    while length > 0:
        if length < delta_q and i > 0:
            for j in range(len(q2_line)):
                qs_new[j] = q2_line[j]
            if not s.empty_collision_checker(qs_new) or not s.obstacle_free(qs_new):
                return qs
            break
        else:
            for j in range(len(q1_line)):
                qs[j] = q1_line[j] + i * delta_q * direction[j]
            if get_euclidean_distance(qs, alpha_i) < nearest_point[1]:
                nearest_point = [i, get_euclidean_distance(qs, alpha_i)]
            length = length - delta_q
            i = i + 1
    for j in range(len(q1_line)):
        qs[j] = q1_line[j] + (i - 1) * delta_q * direction[j]
    return qs


def RRT(world, obstacles, query, max_samples, resolution, p = 0.01):
    s = search_space(world, obstacles)
    g = graph.Graph()
    qI = query[0]
    qG = query[1]
    g.add_vertex(qI)
    alpha_i = s.sample_free()
    g.add_vertex(alpha_i)
    g.add_edge(alpha_i, qI)

    for i in range(max_samples):
        if i % 100 == 0:
            alpha_i = qG
        else:
            if np.random.uniform(0, 1) > p:
                alpha_i = s.sample_free()
            else:
                alpha_i = qG
        min_distance = 1000
        qn = copy.deepcopy(qI)
        vertex = copy.deepcopy(qI)
        for key, value in g.edges.items():
            (q, distance) = geometry.get_nearest_point_on_line(key, value[0], alpha_i, resolution)
            if distance < min_distance:
                min_distance = distance
                qn = copy.deepcopy(q)
                vertex = copy.deepcopy(key)
        qs = stopping_config(s, qn, alpha_i, resolution)


    path = [qG]
    current = qG
    if qI == qG:
        return (g, path)
    while not g.edges[current][0] == qI:
        path.append(g.edges[current][0])
        current = g.edges[current][0]
    path.append(qI)
    path.reverse()
    return (g, path)

    
if __name__ == "__main__":
    args = parse_args()
    (O, dt, ORIGIN, W, H, QUERIES, MAX_SAMPLES, RESOLUTION) = parse_desc(args.desc)

    world = geometry.world_2D_obstacle(ORIGIN, W, H)
    obstacles = []
    for i in range(len(O)):
        c = geometry.circular_obstacle(O[0], O[1]-dt)
        obstacles.append(c.get_boundary())

    fig, ax = plt.subplots()
    [g, path] = RRT(world, None, [], MAX_SAMPLES, RESOLUTION)
    X = graph.Grid2DStates(g, world.get_bounds()[0][0], world.get_bounds()[0][1], world.get_bounds()[1][0], world.get_bounds()[1][1], [])
    draw(ax, world.get_bounds(), obstacles, tuple(QUERIES[0][0]), tuple(QUERIES[0][1]), X, path, title="RRT exploaration, neglecting obstacles")

    fig, ax = plt.subplots()
    [g, path] = RRT(ORIGIN, W, H, O, [])
    X = graph.Grid2DStates(g, world.get_bounds()[0][0], world.get_bounds()[0][1], world.get_bounds()[1][0], world.get_bounds()[1][1], [])
    draw(ax, world.get_bounds(), obstacles, tuple(QUERIES[0][0]), tuple(QUERIES[0][1]), X, path, title="RRT exploaration, considering obstacles")

    for i in range(len(QUERIES)):
        fig, ax = plt.subplots()
        [g, path] = RRT(world, obstacles, QUERIES[i], MAX_SAMPLES, RESOLUTION)
        X = graph.Grid2DStates(g, world.get_bounds()[0][0], world.get_bounds()[0][1], world.get_bounds()[1][0], world.get_bounds()[1][1], [])
        draw(ax, world.get_bounds(), obstacles, tuple(QUERIES[i][0]), tuple(QUERIES[i][1]), X, path, title="RRT planning")

    for i in range(len(QUERIES)):
        fig, ax = plt.subplots()
        g = PRM(world, obstacles, QUERIES[i], MAX_SAMPLES, RESOLUTION)
        X = graph.Grid2DStates(g, world.get_bounds()[0][0], world.get_bounds()[0][1], world.get_bounds()[1][0], world.get_bounds()[1][1], [])
        f = graph.GridStateTransition(g)
        U = graph.Grid2DActions(X, f)
        search_result = fsearch(X, U, f, tuple(QUERIES[i][0]), tuple(QUERIES[i][1]), ALG_BFS)
        draw(ax, world.get_bounds(), obstacles, tuple(QUERIES[i][0]), tuple(QUERIES[i][1]), X, search_result["path"], title="PRM planning")

    # result = {"path": search_result["path"]}

    # with open(args.out, "w") as outfile:
    #     json.dump(result, outfile)

