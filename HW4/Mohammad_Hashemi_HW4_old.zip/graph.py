from discrete_search import (
    StateSpace,
    ActionSpace,
    StateTransition
)


class Graph(object):
    def __init__(self):
        Graph.graph = dict()
        Graph.vertices = []
        Graph.edges = dict()

    def add_vertex(self, vertex):
        Graph.graph[vertex] = []
        Graph.vertices.append(vertex)

    def add_edge(self, vertex, parent):
        if Graph.graph.get(vertex) != None:
            Graph.graph[vertex].append(parent)
            if Graph.edges.get(vertex) == None:
                Graph.edges[vertex] = [parent]
            else:
                Graph.edges[vertex].append(parent)


class Grid2DStates(StateSpace):
    def __init__(self, graph, Xmin, Xmax, Ymin, Ymax, O):
        """
        Xmin, Xmax, Ymin, Ymax: floats that defines the boundary of the world
        O:    a list of tuples that represent the grid points
              that are occupied by an obstacle.
              A tuple (i, j) in O means that grid point (i,j) is occupied.
        """
        self.graph = graph
        self.Xmin = Xmin
        self.Xmax = Xmax
        self.Ymin = Ymin
        self.Ymax = Ymax
        self.O = O

    def __contains__(self, x):
        # TODO: Implement this function
        if self.Xmin <= x[0] and x[0] <= self.Xmax and self.Ymin <= x[1] and x[1] <= self.Ymax and x not in self.O:
            return True
        else:
            return False
        raise NotImplementedError

    def get_distance_lower_bound(self, x1, x2):
        # TODO: Implement this function
        return ((x1[0] - x2[0])**2 + abs(x1[1] - x2[1])**2)**0.5
        raise NotImplementedError

    def draw(self, ax):
        if len(self.graph.vertices) > 0:
            for vertex in self.graph.vertices:
                for connection in range(len(self.graph[vertex])):
                    ax.plot([vertex[0], self.graph[vertex][connection][0]], [vertex[1], self.graph[vertex][connection][1]])


class GridStateTransition(StateTransition):
    def __init__(self, g):
        self.graph = g
    
    def __call__(self, x, u):
        # TODO: Implement this function
        return self.graph[x][u]
        raise NotImplementedError


class Grid2DActions(ActionSpace):
    def __init__(self, X, f):
        self.X = X
        self.f = f

    def __call__(self, x):
        # TODO: Implement this function
        possible_actions = [u for u in range(len(self.f.graph[x]))]
        return possible_actions
        raise NotImplementedError