import json, sys, os, argparse, math
import matplotlib.pyplot as plt
from shapely.geometry import Polygon
from hw2_chain_plotter import get_link_positions
from obstacle import Obstacle
from planning import (
    rrt,
    StraightEdgeCreator,
    EuclideanDistanceComputator,
    ObstacleCollisionChecker,
)
from draw_cspace import draw


class TwoDChainObstacle(Obstacle):
    """Define C-space obstacle for a 2D kinematic chain"""

    def __init__(self, all_obs_vertices, W, L, D):
        """Constructor that takes the list [vertices_1, ..., vertices_n] where
        vertices_i is the list of coordinates of the vertices of obstacle i,
        and W, L, and D represent the width, length and distance between joints
        of each link.
        """
        self.obstacles = [Polygon(obs_vertices) for obs_vertices in all_obs_vertices]
        self.W = W
        self.L = L
        self.D = D

    def contain(self, config):
        """Return whether a configuration config = (theta_1, ..., theta_m) of the robot hits the obstacles"""
        (_, all_link_vertices) = get_link_positions(config, self.W, self.L, self.D)
        for link_vertices in all_link_vertices:
            link = Polygon(link_vertices)
            for obs in self.obstacles:
                if link.intersects(obs):
                    return True
        return False


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="Compute path using RRT")
    parser.add_argument(
        "desc",
        metavar="problem_description_path",
        type=str,
        help="path to the problem description file containing the obstacles, the width and length of each link, and the distance between two points of attachment",
    )
    parser.add_argument(
        "--out",
        metavar="output_path",
        type=str,
        required=False,
        default="",
        dest="out",
        help="path to the output file",
    )

    args = parser.parse_args(sys.argv[1:])
    if not args.out:
        args.out = os.path.splitext(os.path.basename(args.desc))[0] + "_out" + ".json"

    print("Problem description: ", args.desc)
    print("Output:              ", args.out)

    return args


def parse_desc(desc):
    """Parse problem description json file to get the problem description"""
    with open(desc) as desc:
        data = json.load(desc)

    all_obs_vertices = data["O"]
    W = data["W"]
    L = data["L"]
    D = data["D"]
    qI = tuple(data["xI"])
    qG = tuple(data["xG"])
    return (all_obs_vertices, W, L, D, qI, qG)


if __name__ == "__main__":
    args = parse_args()

    # Define cspace
    cspace = [(-math.pi, math.pi), (-math.pi, math.pi)]

    # Construct the obstacles and collision checker
    (all_obs_vertices, W, L, D, qI, qG) = parse_desc(args.desc)
    obstacles = [TwoDChainObstacle(all_obs_vertices, W, L, D)]
    collision_checker = ObstacleCollisionChecker(obstacles)

    # Define edge creator and distance computator
    edge_creator = StraightEdgeCreator(0.1)
    distance_computator = EuclideanDistanceComputator()

    # Run RRT and compute the path from root to goal
    (G, root, goal) = rrt(
        cspace=cspace,
        qI=qI,
        qG=qG,
        edge_creator=edge_creator,
        distance_computator=distance_computator,
        collision_checker=collision_checker,
        pG=0.1,
        numIt=10000,
    )
    path = []
    if goal is not None:
        vertex_path = G.get_vertex_path(root, goal)
        path = G.get_path_from_vertex_path(vertex_path)

    # Collect the result
    vertices = [
        {"id": vid, "config": state.tolist()} for (vid, state) in G.vertices.items()
    ]
    edges = list(G.edges.keys())
    result = {"vertices": vertices, "edges": edges, "path": vertex_path}
    with open(args.out, "w") as outfile:
        json.dump(result, outfile)

    # Plot the result
    fig, ax = plt.subplots()
    draw(ax, cspace, [], qI, qG, G, path, "RRT planning for a 2-link robot")
    ax.set_xlabel(r"$\theta_1 (rad)$", fontsize=20)
    ax.set_ylabel(r"$\theta_2 (rad)$", fontsize=20)
    plt.show()
