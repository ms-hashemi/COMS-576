Ray casting grid map
--------------------

This is a 2D ray casting grid mapping example.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Mapping/raycasting_grid_map/animation.gif