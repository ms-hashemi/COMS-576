.. _control:

Control
=================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   inverted_pendulum_control/inverted_pendulum_control
   move_to_a_pose_control/move_to_a_pose_control

